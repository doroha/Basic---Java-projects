
public class TasksArrays {
	
	// Dor ohayon - 204450985.  Checking all the array values ​​are different, checking all the values ​​moving between certain values, and replacing rows of the array of columns and blocks//  
	
	public static boolean isAllDiff(int [] array) {
		  
		  boolean isAllDiff=true;

		for(int i=0; i<array.length; i=i+1) {
			
			for(int j=0; j<array.length; j=j+1) {
				
				
				if(i!=j && array[i]==array[j] ) {          //Checking the array values ​​for each cell in a different set
					
					isAllDiff=false; 
					
				}
				
			}
			
			
		}
		
		return isAllDiff;
	}
	
	
	
	public static boolean isMatrixBetween(int[][] matrix, int n, int min, int max) {
		
		
		boolean isMatrixBetween=true;
		
		if(matrix==null || matrix.length != n) {     
			isMatrixBetween=false;
		}
		
		
		for (int i=0;i<n;i=i+1) {          
			
			if(matrix[i].length!=n  || matrix[i]==null) {
				isMatrixBetween=false;
			}
			
			for (int j=0;j<n;j=j+1) {
				
				if(( matrix[i][j]< min) || (matrix[i][j]>max)  ) {            // check every cell in the array if the value that inside him is between minimum value and maximum value //
					
					isMatrixBetween=false;
				
				}
					
			}
		}
		
		return isMatrixBetween;
	}
	
	
	
	
	public static int[][] columns (int[][] matrix) {
		
		
		int temp;                  //  temp - variable to keep value for replaces array values 
		int i=0;                    
		int j=0;
		
		while(i<matrix.length) {
			
			while(j<matrix.length) {                 // Change array values ​​from row to column
				
			  temp=matrix[i][j];
			  matrix[i][j]=matrix[j][i];
			  matrix[j][i]=temp;
			  
			  j=j+1;
			  
			}	
			
			i=i+1;
			j=i;
			
		} 
		
		return matrix ;
		
	}
	
	
	
	
	public static int[][] blocks(int[][] matrix, int sqrtN) {
		

		int newrow;              // newrow - variable for the row index in the new board .
		int newcolumn;           // newcolumn - variable for the column index in the new board. 
		int a;
		int b;
		int c;
		int d;
		
        int [][]boardblocks=new int [sqrtN*sqrtN][sqrtN*sqrtN];   // new array for the new blocks.
        		
        		
		for (int i=0;i<sqrtN*sqrtN;i=i+1) {
			
			for(int j=0;j<sqrtN*sqrtN;j=j+1) {
				
                  a=i/sqrtN;
                  b=j/sqrtN;
                  c=i%sqrtN;
                  d=j%sqrtN;
                  
                  newrow=(a*sqrtN)+b;
                  newcolumn=(c*sqrtN)+d;
                  
                  boardblocks[newrow][newcolumn]=matrix[i][j];

					}
				}
				
				return boardblocks;
		
			}
			
}
