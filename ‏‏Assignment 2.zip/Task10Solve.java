
public class Task10Solve {
	
	// Dor Ohayon - 204450985 - Solving the sudoku problem by reducing the problem of flow rates the Boolean.
	
	public static int[][] solve(int sqrtN, int[][] hints) {
		
		
		int[][][]map=Task7Map.varsMap(sqrtN*sqrtN);    //Create a table of variables suitable for the instance.
		   
		
		SATSolver.init(sqrtN*sqrtN*sqrtN*sqrtN*sqrtN*sqrtN);          //initialization the Sat solver- CNF variables that will appear in the CNF formula will be between 1-n^3 .      

		
		Task8Encode.encode(sqrtN,hints,map);     // Encode the instance, using the variable table, to the CNF formula and add the sentences to the solver .
		
		
		boolean[]assignment=SATSolver.getSolution();
		
		int [][]board=new int[sqrtN*sqrtN][sqrtN*sqrtN];
		
		if (assignment==null) {
			
		throw new RuntimeException("timeout");
			
		}
		else if(assignment.length==0) {
			
			board= null;
		}
		else if(assignment.length>0) {

			boolean isSolution=Task5Verify.isSolution(sqrtN,hints,board);
			
			if (isSolution==true) {
				board=Task9Decode.mapToBoard(map,sqrtN*sqrtN,assignment);
			}
			else
				throw new RuntimeException("The solution is illegal");
			
		}
		
         return board;
	}
	
}
