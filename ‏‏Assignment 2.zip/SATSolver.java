
public class SATSolver {
	public static void init(int varCnt, int timeout) {
		throw new UnsupportedOperationException("This SATSolver is only for the submission. During your work, use the full SATSolver, and when you submit use this stub SATSolver.");
	}
	
	public static void init(int varCnt) {
		throw new UnsupportedOperationException("This SATSolver is only for the submission. During your work, use the full SATSolver, and when you submit use this stub SATSolver.");
	}
	
	private static void verifiedClause(int[] clause) {
		throw new UnsupportedOperationException("This SATSolver is only for the submission. During your work, use the full SATSolver, and when you submit use this stub SATSolver.");
	}
	
	public static void addClause(int[] clause) {
		throw new UnsupportedOperationException("This SATSolver is only for the submission. During your work, use the full SATSolver, and when you submit use this stub SATSolver.");
	}
	
	public static void addClauses(int[][] clauses) {
		throw new UnsupportedOperationException("This SATSolver is only for the submission. During your work, use the full SATSolver, and when you submit use this stub SATSolver.");
	}
	
	public static int[] getModel() {
		throw new UnsupportedOperationException("This SATSolver is only for the submission. During your work, use the full SATSolver, and when you submit use this stub SATSolver.");
	}
	
	public static boolean[] getSolution() {
		throw new UnsupportedOperationException("This SATSolver is only for the submission. During your work, use the full SATSolver, and when you submit use this stub SATSolver.");
	}
	
}
