
public class Task9Decode {
	
	
	// Dor Ohayon - 2004450985 - Decode the cnf formula from the Satsolver.
	
	public static int cellValue(int[][][] map, int i, int j, boolean[] assignment) {
		
		
		int row=i;
		int column=j;
		int n=map.length;
		boolean assign=false;    // boolean variable that means if we get to true value in boolean[] assignment  we stop to check the other values and we calculate and return the value of the correct value.
		int k=1;
		
		int x=(n*n*row)+(n*column)+1;
		
		while ((assign==false)&&(x<x+n)) {
			
			                                                   // index of checking the value in assignment array 
				
				if (assignment[x]==true) {
					
					assign=true;
					
				}
				else   
					
					  k=k+1;
				      x=x+1;
			
		
		}
		
		if (assign==false) {    // if all the values in assign are false we throw an Exception.
			
			throw new RuntimeException();
			
		}
		
		
		else  
			
			return  k;       //  k - the true value, and the value is - k.
	

	}
	
	
	
	public static int[][] mapToBoard(int[][][] map, int n, boolean[] assignment)  {
		
		
		int [][]board=new int[n][n];
		
		int cellvalue;
		
		for (int i=0;i<n;i=i+1) {
			
			for(int j=0;j<n;j=j+1) {
				
				cellvalue=cellValue(map,i,j,assignment);    //using cellvalue function to get the value of every cell in board. 
				
				board[i][j]=cellvalue;       // input every cell in board with the correct value.
				
			}
			
		}
		
		return board ;
		
	}
	
}
