
public class Task6Cnf {
	
	// Dor ohayon - 204450985- The definition of three Boolean formulas each will be constrained by a set of
	// CNF Variables A formula expresses a constraint on a set of CNF variables if its set of assignment positions match
	// All the ways in which the constraint can be provided. Given constraint, we would like to define a formula that its set of assigns
	// Exactly matches the ways in which the constraint can be satisfied.
	
	
	public static int[][] atLeastOne(int[] vars) {
		
		int[][]cnf=new int[1][vars.length];
		
		for(int i=0; i<vars.length; i=i+1) {     // Returns the CNF formula that its supply group provides
		                                          // matches all the ways in which you can give true value to at least one of the CNF variables in the input array
			
			cnf[0][i]=vars[i];
		}
		
		return cnf ;
	}
	
	
	
	public static int[][] atMostOne(int[] vars) {
		
		
		int rowcnf= (vars.length*(vars.length-1))/2;    //The number of rows in the cnf formula depends on the number of the clauses, the number of the clauses depends on the number of variables that exist in the vars array.
		
		int[][]cnf=new int[rowcnf][2];      // every clause Contains two literals , It is not true that the pair of variables are both true- for every literal.
		
		int rcnf=0;        //index for the row of cnf formula. 
		int literalvars;     //the literal that we check against the other literals in cnf formula.
		
		for(int i=0;i<vars.length-1;i=i+1) {
			
			literalvars=vars[i]*-1;
			
			   for(int j=i+1; j<vars.length;j=j+1) {     //for every literal we put in clause and check for him that it is not true that the pair of variables are both true- for every other literal.
				   
				   cnf[rcnf][0]=literalvars;
				   cnf[rcnf][1]=vars[j]*-1;
				   
				   rcnf=rcnf+1;
				   
			   }
		}
		
		return cnf ;
		
	}
	

	
	public static int[][] exactlyOne(int[] vars) {
		
		
		int[][]cnf1= atLeastOne(vars);            //cnf1 - At least one of the variables gets a true value.
		int[][]cnf2= atMostOne(vars);           // cnf2- At most one of the variables gets a true value.
		int rowcnf3=cnf1.length+cnf2.length;     
		
		int[][]cnf3=new int[rowcnf3][];   //cnf3 is - cnf1 Conjunction with cnf2 that means - Exactly one  of the variables get a true value.
	     
		cnf3[0]=cnf1[0];      //the first row in cnf3 is the clause -At least one of the variables gets a true value - cnf1
		
		for(int i=1;i<rowcnf3-1;i=i+1) {        //the other rows in cnf3 are the clauses from cnf2.
			
			cnf3[i]=cnf2[i-1];
			
		}
		
		cnf3[rowcnf3-1]=cnf2[cnf2.length-1];     //the last row in cnf3 is last row in cnf2 , i did it separately to avoid an exception.
		
		
		
		return cnf3 ;
	}
	
	
}
