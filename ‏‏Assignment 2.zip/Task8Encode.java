
public class Task8Encode {
	
	// Dor ohayon - 204450985 -  Encode to Satsolver formula.
	
	public static void encode(int sqrtN, int[][] hints, int[][][] map) {
		
		                                           // The function uses auxiliary functions and inserts into the Satolver all the appropriate clauses for each cnf variable so that one of the variables is true for each cell, for each variable exactly one true for each row, column, and block.
		cellcnf (sqrtN, map);                     //The function matches exactly one of the variables correctly within each cell.
		
		rowcnf (sqrtN, map);                      // The function matches exactly each of the variables correctly in each row.
		
		colmuncnf (sqrtN, map);                    // The function matches exactly each of the variables correctly in each column.
		
		blockcnf (sqrtN, map);                    // The function matches exactly each of the variables correctly in each block.
		
		hintscnf (sqrtN,hints,map);         // The function requires the instance variable to get a true value for the resulting clue.
	
		
	}
	
	
	public static void cellcnf (int sqrtN, int[][][] map) {
		
		
		for (int i=0;i<sqrtN*sqrtN;i=i+1)
		{
			for (int j=0;j<sqrtN*sqrtN;j=j+1)
			{
				
				SATSolver.addClauses(Task6Cnf.exactlyOne(map[i][j]));    //Adding a clause to Satsolver that defines - exactly one of the values ​​- 1-n is true value.     
				
			}
		}
	
	}
	
	public static void rowcnf (int sqrtN, int[][][] map) {
		
		int []rowcnf=new int [sqrtN*sqrtN];
		
		for(int i=0;i<sqrtN*sqrtN;i=i+1) { 
			
			for(int k=0;k<sqrtN*sqrtN;k=k+1) {
				
				for(int j=0;j<sqrtN*sqrtN;j=j+1) {
					
					rowcnf[j]=map[i][j][k];
				}
				
				SATSolver.addClauses(Task6Cnf.exactlyOne(rowcnf));          //For each variable - cnf - we check that exactly one is true for each cnf variable that corresponds to the same variable in the row - for each cnf variable exactly one gets True in the given placement that we get in satsolver.   
			}
		}

	}
	
	public static void colmuncnf (int sqrtN, int[][][] map) {
		
		int[] temp=new int [sqrtN];                  //  temp - variable to keep value for replaces array values 
		int i=0;                    
		int j=0;
		
		while(i<map.length) {
			
			while(j<map.length) {                 // Change array values ​​from row to column
				
			  temp=map[i][j];
			  map[i][j]=map[j][i];
			  map[j][i]=temp;
			  
			  j=j+1;
			  
			}	
			
			i=i+1;
			j=i;
			
		} 
		
		rowcnf (sqrtN,  map);     // send to rowcnf --> map , when all rows are columns - the function will check that for each cnf variable exactly one is true for each cnf variable that corresponds to the same variable in the column - for each cnf variable exactly one gets True in the given placement that we get in satsolver.
		
	}
	

	
	
	public static void blockcnf (int sqrtN,int[][][] map) {
		
		
		   
		
		int newrow;              // newrow - variable for the row index in the new board .
		int newcolumn;           // newcolumn - variable for the column index in the new board. 
		int a;
		int b;
		int c;
		int d;
		
        int[][][]boardblocks=new int [sqrtN*sqrtN][sqrtN*sqrtN][sqrtN*sqrtN];   // new array for the new blocks.
        		
        		
		for (int i=0;i<sqrtN*sqrtN;i=i+1) {
			
			for(int j=0;j<sqrtN*sqrtN;j=j+1) {
				
                  a=i/sqrtN;
                  b=j/sqrtN;
                  c=i%sqrtN;
                  d=j%sqrtN;
                  
                  newrow=(a*sqrtN)+b;
                  newcolumn=(c*sqrtN)+d;
                  
                  boardblocks[newrow][newcolumn]=map[i][j];

					}
				}
				
	
		
		rowcnf (sqrtN,boardblocks);     // send to rowcnf --> boardblocks , when all rows are blocks - the function will check that for each cnf variable exactly one is true for each cnf variable that corresponds to the same variable in the block - for each cnf variable exactly one gets True in the given placement that we get in satsolver.

	}
	
	public static void hintscnf (int sqrtN, int[][] hints, int[][][] map) {
		
		int row;
		int column;
		int value;
		int [] clause=new int [1];
		
		for(int i=0;i<hints.length;i=i+1) {
			
			row=hints[i][0];
			column=hints[i][1];
			value=hints[i][2];
			clause[0]=Task7Map.varName(row,column,value-1,sqrtN*sqrtN);    // Calculates the value that will appear in the map-variables table for the values ​​we get as hints, using the varName function.
			SATSolver.addClause(clause);	
			
			
		}
		

	}
	
}
