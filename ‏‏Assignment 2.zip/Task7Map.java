
public class Task7Map {
	
	// Dor Ohayon - 204450985 - Coding constraints to cnf and using them to solve the Boolean problem. 
	
	public static int varName(int i, int j, int k, int n) {
		
		int varName=(n*n*i)+(n*j)+k+1;
	
		return varName ;
	}
	
	
	public static int[] nameToIndex(int x, int n) {
		
	
		int i;
		int j;
		int k;
		
		k=(x-1)%n;                                //(n*n*i)+(n*j)+k+1=x -->   (n*n*i)+(n*j)+k=x-1   --> k = division's remainder of (x-1) with "n", (n*n*i)/n -  divide without remainder of division and  (n*j)/n - divide without remainder of division .                     
		j=((x-k-1)/n)%n;                           // (n*n*i)+(n*j)+k+1=x  --> (n*n*i)+(n*j)=x-1-k  --> n*i+j=(x-1-k)/n --> j =  division's remainder of ((x-1-k)/n) with "n" , (n*i) - divide without remainder of division.
		i=((x-k-1)/n-j)/n;                         // (n*n*i)+(n*j)+k+1=x  --> (n*n*i)+(n*j)=x-1-k --> n*i+j=(x-1-k)/n -->  n*i= ((x-1-k)/n)-j -->  i=((x-k-1)/n-j)/n .
		
		int [] triplet= {i,j,k};
		
	
		return triplet ;
		
	}
	
	
	public static int[][][] varsMap(int n) {
		
		int [][][] map=new int[n][n][n];
		
		
		for(int i=0;i<n;i=i+1) {
			for(int j=0;j<n;j=j+1) {
				for(int k=0;k<n;k=k+1) {
					
					map[i][j][k]=varName(i,j,k,n);    //Placement The three dimensional array . 
					
				}	
			}
		}
		return map;

	}
}
