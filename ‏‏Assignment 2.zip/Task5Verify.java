
public class Task5Verify {
	
	// Dor ohayon - 204450985 - Check for a valid Sudoku solution.  
	
	public static boolean isSolution(int sqrtN, int[][] hints, int[][] board) {
	
		
		
		if (TasksArrays.isMatrixBetween(board,sqrtN,1,sqrtN*sqrtN)==false) {      // check the matrix board, if board is an matrix of sqrtN^2*sqrtN^2 and Its values ​​are between 1-sqrtN . 
			
			throw new RuntimeException("exception");
			
		}
		
		
		for(int i=0;i<sqrtN*sqrtN;i=i+1) {   //check the matrix board if all the row values ​​are different.
			
			if(TasksArrays.isAllDiff(board[i])==false) {
				
				return false;
			}
			
		}
		
		
		int[][]boardcolumns=TasksArrays.columns(board);     
		
		for(int i=0;i<sqrtN*sqrtN;i=i+1) {     // check the matrix board columns if all the columns values ​​are different.
			
			if(TasksArrays.isAllDiff(boardcolumns[i])==false) {
				
				return false;
			}
		}
		
		
		
		int[][]boardblocks=TasksArrays.blocks(board,sqrtN);
		
		for(int i=0;i<sqrtN*sqrtN;i=i+1) {     // check the matrix board blocks sqrtN*sqrtN , if all the blocks values ​​are different.
			
			if(TasksArrays.isAllDiff(boardblocks[i])==false) {
				
				return false;
			}
		}
		
		
		
		int row;
		int column;
		int value;
		
		for(int i=0;i<hints.length;i=i+1) {      // Check whether the hints values ​​match the Sudoku tab values.
			
			row=hints[i][0];
			column=hints[i][1];
			value=hints[i][2];
			
			if(board[row][column]!=value) {
				
				return false;
				
			}
		
		}
		
		
		
		return true ;
	}


}
