/*---------------------------------------
 Genuine author: Dor Ohayon, I.D.: 204450985
 Date: 08-12-2017 
 The class studentinfo - represents all of the student's information. This information has five characteristics that define it: Name
The student's last name, the student's ID number, the total number of credits that the student must complete
To complete the degree and number of credits that the student has completed so far. Each student has his own unique ID number but the name or
Last name must not be unique.
---------------------------------------*/

/* Administrative information of a student */
public class StudentInfo {
	
     private String firstname;
     private String lastname;
     private String Address;
     
     private int identityNumber;
     private int maxCredit;
     private int RequiredCredits;
     private int credit=0;

    public StudentInfo(String firstName, String familyName, int identityNumber, int maxCredit) {  //The constructor initializes the fields according to the conditions which depends on different Students Info//
    	
    	boolean correctFname=true;   //A variable to check the integrity of the First name input//
    	boolean correctLname=true;   //A variable to check the integrity of the Last name input//
    	
		if(firstName==null || firstName.length()==0) {
		correctFname=false;
		}
		if(correctFname==true) {
			int i=0;
			while(correctFname==true && i<firstName.length()) { //The received string as input must contain only uppercase and lowercase English letters//
				if(!((firstName.charAt(i)>='a' & firstName.charAt(i)<='z') || (firstName.charAt(i)>='A' & firstName.charAt(i)<='Z'))){
					correctFname=false;
				}
				i=i+1;
			}
		}
		if(correctFname==true) {   //If one of the conditions did not take place throwing an exception//
			this.firstname=firstName;
		}
		else throw new IllegalArgumentException();
		
		if(familyName==null || familyName.length()==0) {
		correctLname=false;
		}
		if(correctLname==true) {
			int j=0;
			while(correctLname==true && j<familyName.length()) { //The received string as input must contain only uppercase and lowercase English letters//
				if(!((familyName.charAt(j)>='a' & familyName.charAt(j)<='z') || (familyName.charAt(j)>='A' & familyName.charAt(j)<='Z'))){
					correctLname=false;
				}
				j=j+1;
			}
		}
		if(correctLname==true) {   //If one of the conditions did not take place throwing an exception//
			this.lastname=familyName;
		}
		else throw new IllegalArgumentException();

		
		if(identityNumber>0) {
		this.identityNumber=identityNumber;
		}
		else throw new IllegalArgumentException(); 
		
		if(maxCredit>0) {
		this.maxCredit=maxCredit;	
		}
		else throw new IllegalArgumentException();   
    }
    
    public String getFirstName() {
       return this.firstname;
    }
    
    public String getFamilyName() {
        return this.lastname; 
    }
    
    public int getIdentityNumber() {
        return this.identityNumber; 
    }
    
    public int getRequiredCredits() {
       this.RequiredCredits=this.maxCredit-this.credit;
       return this.RequiredCredits;
    }
    
    public void addCredit(int credit) {
    	if(credit<0) {
    	throw new IllegalArgumentException();
    	}
    	else
    	this.credit=this.credit+credit;
    }
    
    public int getCredit() {
        return this.credit; 
    }
    
    public String getAddress(){
    	if(this.Address==null) {
    		return "";
    	}
    	else
        return this.Address;
    }
    
    public void setAddress(String address){
    	
    	boolean correctaddress=true;

		if(address==null || address.length()==0) {
		   correctaddress=false;
		}
		if(correctaddress==true) {
			int k=0;
			while(correctaddress==true && k<address.length()) { //The received string as input must contain only uppercase and lowercase English letters and spaces//
				if(!((address.charAt(k)>='a' & address.charAt(k)<='z') || (address.charAt(k)>='A' & address.charAt(k)<='Z') || (address.charAt(k)==' '))){
					correctaddress=false;
				}
				k=k+1;
			}
		}
		if(correctaddress==true) {   //If one of the conditions did not take place throwing an exception//
			this.Address=address;
		}
		else throw new IllegalArgumentException();
    }
    
	public String toString(){
		
		return "First name:"+this.firstname+"\n"+                    //"\n" - Down line // 
	            "Last name:"+this.lastname+"\n"+
	            "ID:"+this.identityNumber+"\n"+
	            "Address:"+this.Address+"\n"+
	            "MaxCredit:"+this.maxCredit+"\n"+
	            "Number of current credits:"+this.credit+"\n"+
	            "Required Credits:"+this.RequiredCredits+"\n" ;     
	}
	
	public boolean isEqualTo(StudentInfo other){
		if(other.identityNumber==this.identityNumber) 
			return true;
		else return false;
	}
}
