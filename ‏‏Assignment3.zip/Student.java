/*---------------------------------------
 Genuine author: Dor Ohayon, I.D.:204450985
 Date: 09-12-2017
 The class Student- A student is defined by the administrative information about him.
---------------------------------------*/

public class Student {

	StudentInfo studentinfo;
	private int sumgrade=0;
	private double averageGrade=0.0;
	
    public Student(String firstName, String familyName, int identityNumber) {
    	studentinfo=new StudentInfo(firstName,familyName,identityNumber,120);
    }
    
    public StudentInfo getStudentInfo(){
        return studentinfo; 
    }
    
    public void addCourseGrade(Course course, int grade) {
    	int credits=course.getCredits();
      	this.sumgrade=this.sumgrade+(grade*credits);     //To calculate the average grade - for each course a different weight on average, the formula is calculated using the formula - the number of credits of the course double the score that the student received in the course , divided with the number of credits of the courses that made//    
    	studentinfo.addCredit(credits);
    }
    
    public double averageGrade() {
    	this.averageGrade=this.sumgrade/studentinfo.getCredit();             //Division the scores by the weight of each score with the number of credits of the courses that made//
        return this.averageGrade;
    }
    
	public String toString(){
		return studentinfo.toString()+"\n"+
			   "Average Grade ="+this.averageGrade+"\n";
	}
	
	public boolean isEqualTo(Student other){
		if(studentinfo.isEqualTo(other.getStudentInfo()))
		return true;
		else
		return false;
	}
}
