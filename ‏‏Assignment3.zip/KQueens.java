/*---------------------------------------
 Genuine author: Dor Ohayon, I.D.: 204450985
 Date: 10-12-2017
 The class KQueens - The problem of KQueens - representation of a proposed solution and its printing, checking the legality of a proposed solution, adding a queen to a given table, using the recursion to solve the K Queens problem.
---------------------------------------*/
public class KQueens {

	public static void printBoard(boolean[][] board) { //Printing Solution Board//

		if(board.length==0) {
	    System.out.println("There is no solution");
		}
		else {
			for(int i=0;i<board.length;i=i+1) {
				for(int j=0;j<board.length;j=j+1) {
					if(board[i][j]==true) {
						System.out.print("Q"+' ');
					}
					else {
						System.out.print("*"+' ');
					}
				}
				System.out.println();
			}
	   }
	}
	
	public static boolean isQueenThreatened(boolean[][] board, int row, int col) {
        
		boolean QueenThreatened = false;
		int counterQueens=0; //Total queens threatening - maximum 2//
		int counterow1=0; //Each counter checks the number of threatening queues by row, column, and diagonals//
		int counterow2=0;
		int countercol1=0;
		int countercol2=0;
		int counterdia1=0;
		int counterdia2=0;
		int counterdia3=0;
		int counterdia4=0;
		
		for(int i=row; i<board.length-1 && counterQueens<1;i=i+1) { //Checking for a threatening queen on the right side of the line//
			if(board[row][i+1]==true)counterow1=counterow1+1;
		}
		for(int i=row; i>1 && counterow2<1; i=i-1) {  //Checking for a threatening queen on the left side of the line//
			if(board[row][i-1]==true)counterow2=counterow2+1;
		}
		
		counterQueens=counterow1+counterow2;
		
		if(counterQueens<2) { //If no threatening queens are found, we continue our examination//
			
			for(int i=col; i<board.length-1 && countercol1<1;i=i+1) { //Check queens for values ​​in the column below the desired queen//      
				if(board[i+1][col]==true)countercol1=countercol1+1;
			}
			
			counterQueens=counterQueens+countercol1;
			
			if(counterQueens<2) {
				
			for(int i=col; i>1 && countercol2<1; i=i-1) { //Check queens for values ​​in the column above the desired queen// 
				if(board[i-1][col]==true)countercol2=countercol2+1;
			}
			
			counterQueens=counterQueens+countercol2;
			
			if(counterQueens<2) {
				
				int rowdia1=row;
				int coldia1=col;
				while((counterdia1<1) && ((rowdia1<board.length-1)&&(coldia1<board.length-1))) { //Check for threatening queens from the right diagonal downward//
				      if(board[rowdia1+1][coldia1+1]==true) counterdia1=counterdia1+1;	
						rowdia1=rowdia1+1;
						coldia1=coldia1+1;
			}
				counterQueens=counterQueens+counterdia1;
				
				if(counterQueens<2) {
					
					int rowdia2=row;
					int coldia2=col;
					while((counterdia2<1) && ((rowdia2>0)&&(coldia2<board.length-1))) {  //Check for threatening queens from the right diagonal upward//
					      if(board[rowdia2-1][coldia2+1]==true) counterdia2=counterdia2+1;
							rowdia2=rowdia2-1;
							coldia2=coldia2+1;
				}
					
					counterQueens=counterQueens+counterdia2;
					
					if(counterQueens<2) {
						
						int rowdia3=row;
						int coldia3=col;
						while((counterdia3<1) && ((rowdia3<board.length-1)&&(coldia3>0))) { //Check for threatening queens from the left diagonal below//
						      if(board[rowdia3+1][coldia3-1]==true) counterdia3=counterdia3+1;
								rowdia3=rowdia3+1;
								coldia3=coldia3-1;
					}
						
						counterQueens=counterQueens+counterdia3;
						
						if(counterQueens<2) {
							
							int rowdia4=row;
							int coldia4=col;
							while((counterdia4<1) && ((rowdia4>0)&&(coldia4>0))) { //Check for threatening queens from the left diagonal above//
							      if(board[rowdia4-1][coldia4-1]==true) counterdia4=counterdia4+1;
									rowdia4=rowdia4-1;
									coldia4=coldia4-1;
						}
							counterQueens=counterQueens+counterdia4;
						}	
					}
				}
			}	
		}	
	}
			if(counterQueens==2) QueenThreatened=true;  //If two queens are found threatening then the Queen is threatened//

		   return QueenThreatened; 
	}

	public static boolean isLegalSolution(boolean[][] board, int k) {

		boolean isLegalSolution=true;
		int counterKQueens=0; 
		
		for(int i=0; i<board.length && isLegalSolution==true; i=i+1) {
			
			for(int j=0; j<board.length && isLegalSolution==true; j=j+1) {
				
				if(board[i][j]==true) {
					counterKQueens=counterKQueens+1;  //If two queens are found threatening then the Queen is threatened//
					if(isQueenThreatened(board,i,j)==true) isLegalSolution=false;  //If the queen is threatened by 2 queens then the solution is illegal//
				}
			}
		}
		
		if (isLegalSolution==true) { //If the queen is not threatened by two queens, but the number of queens in the solution board is not equal to the number of queens that we received as input// 
			if(counterKQueens!=k) isLegalSolution=false;
		}
		
		return isLegalSolution; 
	}
	
	public static boolean addQueen(boolean[][] board, int row, int col, int numOfQueens) {

       boolean possible=false;
       
       board[row][col]=true; //Assigning a queen by line and column received as input//
       
       if(isLegalSolution(board,numOfQueens+1)==true) {
    	   possible=true;
       }
       
       if(possible==false) board[row][col]=false;
		return possible; 
	}
	
	
	public static boolean[][] kQueens(int n, int k){
		
		boolean[][]board=new boolean [n][n];
		boolean[][]emptyboard = new boolean [0][0];
		
		if(kQueens(board,k,0,0,0)==true) return board;  //If the board solution is legal solution we return board else- we return empty board// 
		else 
		return emptyboard;
	}
	
	private static boolean kQueens(boolean[][] board, int k, int row, int
			col, int numOfQueens) {
		

              return true;
		}
	}
