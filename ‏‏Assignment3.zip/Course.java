/*---------------------------------------
 Genuine author: Dor Ohayon, I.D.: 204450985
 Date: 08-12-2017
 
 The class Course - The course has three characteristics that define it: name, number, and number of credits awarded by the course.
---------------------------------------*/

public class Course {

	private int number;
	private int credits;
	private String name;
	
	public Course(String name, int number, int credits) {     //The constructor initializes the fields according to the conditions which depends on different courses.//
     
		boolean correctname=true;       //A variable to check the integrity of the name input//
		
		if(name==null || name.length()==0 )   {
			correctname=false;
		}
		
		if(correctname==true) {
			int i=0;
		    while(correctname==true && i<name.length()) {   //The received string as input must contain only uppercase and lowercase English letters, numbers, and spaces//
			
			if(!((name.charAt(i)>='a' & name.charAt(i)<='z') || (name.charAt(i)>='A' & name.charAt(i)<='Z') || (name.charAt(i)==' ') ||  (name.charAt(i)>='0' & name.charAt(i)<='9'))) {
				correctname=false;
			}
	        i=i+1;
			}
		}
		if(correctname==true) {       //If one of the conditions did not take place throwing an exception//
			this.name=name;
		}
		else throw new IllegalArgumentException(); 
		
		if(credits>0) {
		this.credits=credits;
		}
		else throw new IllegalArgumentException(); 
		
		if(number>0) {
		this.number=number;	
		}
		else throw new IllegalArgumentException(); 

	}
	
    public String getName() {
        return this.name; 
    }
    
    public int getCredits() {
        return this.credits;
    }
    
    public int getNumber() {
        return this.number;
    }
    
	public String toString(){
		return "Name of course:"+this.name +
			   "Number of course:" + this.number +
			   "Number of credits:" + this.credits; 
	}
	
	public boolean isEqualTo(Course other){
		if(other.number==this.number)
		return true;
		else
		return false; 
	}
}
