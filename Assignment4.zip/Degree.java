public abstract class Degree {

    public Degree(String name, int degreeCode, int requiredCredits) {


    }

    public Degree() {


    }

    public String getDegreeName(){
    	return null; 
    }

    public int getDegreeCode()
    {
    	return 0;
    }

    public List<Course> getMandatoryCourses() {
    	return null;
    }

    public List<Course> getElectiveCourses() {
    	return null;
    }

    public boolean addCourse(Course course,boolean mandatory){
    	return false;
    }
    
    public int getRequiredCredits(){
    	return 0;
    }

    public int getMandatoryCredits(){
    	return 0;
    }

}
