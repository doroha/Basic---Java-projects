import javafx.util.Pair;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
//Dor Ohayon -2004450985
public class StudentManagementSystem {

    private List<Student> Students;
    private List<Degree> Degree;
    private List<Course> Courses;
    private int Minvalue;

    public StudentManagementSystem(int failTreshold) {
        Students=new LinkedList<>();
        Degree=new LinkedList<>();
        Courses=new LinkedList<>();
        this.Minvalue=failTreshold;
    }

    public boolean addStudent(Student student){
        boolean Itispossible=true;
        if(Students.contains(student))
            Itispossible=false;

        if (Itispossible==true && Degree.contains(student.getDegree())){
            Students.add(student);
            return true;} //If there is no student in the system and there is also the degree that the student is studying in the system of degrees, the value that returned is truth.
        return false;
        }

    public boolean addCourse(Course course){
        boolean Itispossible=true;
        if(Courses.contains(course))
            Itispossible=false;
        for(Course cours:course.getAllPreliminaryCourses()){
            if(!Courses.contains(cours))
                Itispossible=false;}
        if (Itispossible==true){
            Courses.add(course);
            return true;} //If there is no course in the system and The system contains all pre-courses of the course, the value that returned is truth.
            return false;
    }

    public boolean addDegree(Degree degree) {
        boolean Itispossible=true;
        Iterator<Degree>degreeIterator=Degree.iterator();
        while (degreeIterator.hasNext()){
            if (degreeIterator.next().equals(degree))
                Itispossible=false; //Checking if the degree Exists in the system.
        }
        if (Itispossible==true ){
            Degree.add(degree);
            return true;} //If the degree does not exist in the system and the system contains the duty and choice of the title is returned value true.
            return false;
    }

    public List<Course> getMissingPreCourses(Course course, int studentId){

        List<Course>MissingPreCourses=new LinkedList<Course>();
        List<Course>registeredCourses=RegisteredCourses(studentId); //RegisteredCourses()-  Auxiliary function for finding a list of courses
        for (Course precourse: course.getAllPreliminaryCourses()) {  //Perform a review of the course's Pre-Course list
             if (!(registeredCourses.contains(precourse)))
                 MissingPreCourses.add(precourse); //If the course is not listed in the list of courses to which the student is enrolled, then add this pre-course to the list of courses that the student must complete for registration for the required course.
        }
        Sorter.bSort(MissingPreCourses);
        return MissingPreCourses;
    }

    public List<Course> RegisteredCourses(int studentId){  //Auxiliary function for finding a list of registered Courses.

        for (Student s :Students){   //We go through the list of courses and once you find the required student we return the list of courses to which he or she is enrolled.
            if (s.getStudentInfo().getIdentityNumber()==studentId) return s.getRegisteredCourses();
        }
        return  null;
    }
    public Student findingstudent(int studentId){ //An auxiliary function for finding the required student.
        for (Student s:Students){
            if (s.getStudentInfo().getIdentityNumber()==studentId) return s;
        }
        return null;
    }

    public boolean register(int studentId, Course course){
        boolean Itispossible=true;
        Student student=findingstudent(studentId);//finding the required student with the auxiliary function - student.
        if (!(Students.contains(student)) | !(Courses.contains(course))){
            Itispossible=false; }// Check whether the student and the course exist in the system.
       if (Itispossible==true){
        if (!(student.getDegree().getElectiveCourses().contains(course)) && !(student.getDegree().getMandatoryCourses().contains(course)))
            Itispossible=false;// If the course is not on the list of required courses and the choice of the degree that the student is doing then the action is not possible.
        }
       if (Itispossible==true){
           for(Course cours:course.getAllPreliminaryCourses())
               if(!student.isCompleted(cours,Minvalue))
                   Itispossible=false;                                          // If the student did not take the course then registration for the course is carried out differently if he did the registration course will be carried out if and only if the student failed the course.
           if (Itispossible & !(student.getRegisteredCourses().contains(course)) & !student.isCompleted(course,Minvalue))
               student.registerTo(course);
       }
        return Itispossible;
    }

    public boolean addGrade(Course course, int studentId, int grade){
        boolean Itispossible=true;
        Student student=findingstudent(studentId);
        if (!(Students.contains(student)) & !(student.getRegisteredCourses().contains(course)) & !(Courses.contains(course) & !(student.isCompleted(course,grade)))) Itispossible=false;  //To the extent And the student does not exist / is not registered for the course / the course does not exist / the student has already received a passing grade, thesystem will return false.

        if (Itispossible==true) {
            student.addGrade(course,grade);  // adding the new grade.
            return true;
        } else return false;
    }

    public List<Student> closeCourse(Course course, List<Pair<Integer, Integer>> grades)
    {
        List<Student>FailStudents=new LinkedList<Student>();
        Student newstudent;
        for (Pair<Integer, Integer> student:grades){
            newstudent=findingstudent(student.getKey());  //finding the student with his id from the pair.
            newstudent.addGrade(course,student.getValue());
            if (student.getValue()<Minvalue)
                FailStudents.add(newstudent); // if the student does not pass the grade, he adding to the Fail Students list.
        }
        return FailStudents;
    }

    public boolean closeDegree(int studentId, int year){

        Student student=findingstudent(studentId);
        int MandatoryCoursescredits=student.getDegree().getMandatoryCredits();
        int sumcredits=MandatoryCoursescredits;     //suuming all the credits.
        for(Course course:student.getDegree().getMandatoryCourses()){   //Passing all required courses and checking whether the student passed them all successfully
            if (!(student.isCompleted(course,Minvalue))) return false;
        }

        for (Course course:student.getDegree().getElectiveCourses()){   //Check if the student has passed all required courses
            if (student.isCompleted(course,Minvalue))
            sumcredits=sumcredits+course.getCredit();
        }
        if (!(student.getRegisteredCourses().isEmpty())) return false; ////check if the student is still registed to courses.

        if (sumcredits>=student.getDegree().getRequiredCredits()) {
            student.closeDegree(year);
            return true;
        }else return false;
    }

    public List<Student> getFirstKStudents(Degree degree, int year, int k)
    {
        List<Student>FinishFirst=new LinkedList<Student>();
        List<Student>Allfinish=new LinkedList<Student>();
        int counterKstudents=0;
        for (Student student:Students){
            if ((student.getDegree()==degree)&&(student.getFinishYear()==year)){   //check from the list of students who are the students who completed the degree in the year that was received
                FinishFirst.add(student);
                Allfinish.add(student);
                counterKstudents=counterKstudents+1;
            }
        }
        if (counterKstudents>=k){
            Sorter.bSort(FinishFirst);
            return FinishFirst;
        } else {
            Sorter.bSort(Allfinish);
            return Allfinish;
        }
    }

    public List<Student> getFailStudents(Course course){

        List <Student >FailingStudents=new LinkedList<Student>(); //List of all fail student.
        for(Student student:Students) {
            if(student.getCourseGrade(course)!=null) {
                if (student.getCourseGrade(course).getGrade()<this.getFailTreshold()){
                    FailingStudents.add(student);
                }
            }
        }
        return FailingStudents;
    }

    public List<Student> getRegisteredStudents(Course course)
    {
        List<Student>Registed=new LinkedList<Student>();
        for(Student student :Students){
            if(student.isRegisteredTo(course)) Registed.add(student);
        }
        return Registed;
    }

    public List<Course> nextAvailableCourses(int studentId)
    {
        List<Course> nextAvailableCourses=new LinkedList<Course>();
        Student student=findingstudent(studentId);
        Degree degree=student.getDegree();
            for (Course course:degree.getMandatoryCourses()) {
            if( (!student.isCompleted(course, this.getFailTreshold())) && (this.PossibleRegister(course, studentId))) {//if course is not allready comleted and student can register
                nextAvailableCourses.add(course);
            }
        }
        for (Course course:degree.getElectiveCourses()) {
            if( (!student.isCompleted(course, this.getFailTreshold()))) {//if course is not allready comleted and student can register
                nextAvailableCourses.add(course);
            }
        }
        Sorter.bSort(nextAvailableCourses);
        return nextAvailableCourses;
    }

    private boolean PossibleRegister(Course course , int studentId) {  //An auxiliary function for checking whether the student has no pre-completion courses.
        if(this.getMissingPreCourses(course, studentId).isEmpty()) return true;  //if the student has no missing pre courses.
        else return false;
    }

    public List<Course> getMissingCourses(int studentId)
    {
        Student student=findingstudent(studentId);
        List <Course> missingCourse=new LinkedList<Course>();
        missingCourse.addAll(student.getDegree().getMandatoryCourses());
        for(Course course:student.getDegree().getMandatoryCourses()) {
            if(student.isCompleted(course, getFailTreshold())) {
                missingCourse.remove(course);
            }
        }
        return missingCourse;
    }

    public List<Student> getStudents() {
        return this.Students;
    }

    public List<Course> getCourses() {
        return this.Courses;
    }

    public List<Degree> getDegrees() {
        return this.Degree;
    }

    public int getFailTreshold() {
        return this.Minvalue;
    }
}
