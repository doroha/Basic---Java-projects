//Dor Ohayon -2004450985
public class BachelorDegree extends Degree {

    final static int REQUIREDCREDITS = 20;
    public BachelorDegree(String name, int degreeCode)
    {
        super(name,degreeCode,REQUIREDCREDITS); //Build a degree with name,code and 20-Required Credits.
    }
}