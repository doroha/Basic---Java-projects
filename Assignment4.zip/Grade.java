public class Grade {

    private Course course;
    private int grade;
//Dor Ohayon -2004450985
    public Grade(Course course, int grade) {   //Constructor of Grade.
        if (course!=null && (grade>=0 & grade<=100)) {
            this.course = course;
            this.grade = grade;
        } else throw new IllegalArgumentException();
    }

    public Course getCourse() {
        return this.course;
    }

    public int getGrade() {
        return this.grade;
    }

    public int setGrade(int grade) {
        this.grade=grade;
        return this.grade;
    }

    public String toString() {
        return "The grade in course:"+this.course+""+"is:"+this.grade;
    }

    public boolean equals(Object other){
        boolean theyequals=true;
        if (!(other instanceof Grade)) theyequals=false;

        Grade g=(Grade)other;

        if (!(g.getCourse().equals(this.course))) theyequals=false;

        if (g.getGrade()!=this.getGrade()) theyequals=false;

        return theyequals;
    }
}
