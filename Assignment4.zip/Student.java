import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
//Dor Ohayon -2004450985
public class Student implements Comparable<Student>{
    private StudentInfo studentInfo;
    private Degree degree;
    private List<Course> registeredCourses;
    private List<Grade> grades;
    private int currentYear;
    private int finishAt;

    //constructors
    public Student(StudentInfo studentInfo, Degree degree) {
        if (studentInfo == null | degree == null)
            throw new IllegalArgumentException();
        this.studentInfo = studentInfo;
        this.degree = degree;

        this.registeredCourses = new LinkedList<Course>();
        this.grades = new LinkedList<Grade>();
        this.currentYear = 1;
        this.finishAt = 0;

    }

    //methods
    public StudentInfo getStudentInfo(){
        return studentInfo;
    }

    public Degree getDegree() {
        return degree;
    }

    public int getCurrentYear() {
        return currentYear;
    }

    public int getFinishYear() {
        return finishAt;
    }

    public List<Grade> getGrades() {
        return grades;
    }
    public void increaseYear() {
       currentYear=currentYear+1;
    }

    public void closeDegree(int year) {
        this.currentYear=0;
        this.finishAt=year;
    }

    public boolean isRegisteredTo(Course course){

        for (Course registered: registeredCourses ) {
             if (registeredCourses.contains(registered)) return true;
        }
        return false;
    }

    public boolean isCompleted(Course course, int passGrade){
        for (Grade g:grades ) {      //A loop running on the grades list, g-epresents a score .
            if (g.getCourse().equals(course)){
                if (g.getGrade() >= passGrade) return true;
                return false;
            }
        }
        return false;
    }

    public boolean registerTo(Course course){
        if (!(registeredCourses.contains(course))) {
            registeredCourses.add(course);  // Only if the course is not on the list of courses, the course is added to the list.
            return true;
        }
        return false;
    }

    public double averageGrade() {
        int sumgrades=0;    //sum of all the grades
        int sumcredits=0;    // sum of all the credits of the courses
        int credit;
        double avg;   //average grade
        for (Grade grade:grades){
            credit=grade.getCourse().getCredit();    //the credit of each course.
            sumgrades=sumgrades+(grade.getGrade()*credit);
            sumcredits=sumcredits+credit;
        }
        avg=sumgrades/sumcredits;
        return avg;
    }

    public boolean addGrade(Course course, int grade) {
        if (registeredCourses.contains(course)){
            Grade newgrade=new Grade(course,grade);  //Create a new instance of a grade type.
            grades.add(newgrade);
            registeredCourses.remove(course);
            return true;
        }
        return false;
    }

    public int setGrade(Course course, int grade) {
        Grade newgrade=new Grade(course,grade);
        int prevgrade=0;
        Iterator Grades=grades.iterator();
            while (Grades.hasNext()){
            if (Grades.equals(newgrade)){
                prevgrade= (int) Grades.next();
                Grades.remove();
                grades.add(newgrade);
            }
            return prevgrade;
        }
        if (prevgrade==0) throw new IllegalArgumentException();
        else return prevgrade;
    }

    public String toString() {
        return null;
    }

    public boolean equals(Object other) {
        return other instanceof Student && studentInfo.getIdentityNumber() == ((Student) other).studentInfo.getIdentityNumber();
    }

    public List<Course> getRegisteredCourses() {
        return registeredCourses;
    }

    public Grade getCourseGrade(Course c)
    {
            for (Grade g:grades){
                if (g.getCourse().equals(c)){
                    return g;
                }
            }
            return null;
    }

    @Override
    public int compareTo(Student o) {
        if (o.averageGrade()<this.averageGrade()) return 1;  //Comparison as required by the terms of the method.
        else if (o.averageGrade()==this.averageGrade()) {
             if (o.getStudentInfo().getIdentityNumber()>this.getStudentInfo().getIdentityNumber()) return 1;
             return -1;
        } else return -1;

    }
}
