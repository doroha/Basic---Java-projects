import java.lang.reflect.Type;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Course implements Comparable<Course>{

    private String name;
    private int number;
    private int credit;
    private List<Course> preCourses;

    public Course (String name, int credits) {}

    public Course(String name, int number, int credit) {
        if (name == null || name.equals("") | number <=0 | credit <= 0 | credit > 6| !onlyLettersAndSpaces(name))
            throw new IllegalArgumentException();

        this.name = name;
        this.number = number;
        this.credit = credit;
        this.preCourses = new LinkedList<Course>();
    }

    public String getName()
    {
        return name;
    }

    public int getNumber()
    {
        return number;
    }

    public int getCredit()
    {
        return credit;
    }

    public String toString(){
        return "Course: name - " + name + ", number - " + number + ", credit - " + credit + ".";
    }

    public boolean equals(Object other){
        return other instanceof Course && ((Course) other).number == this.number;}


    public List<Course> getPreliminaryCourses()	{
        return preCourses;
    }

    public List<Course> getAllPreliminaryCourses(){
        List<Course>AllPreliminaryCourses=new LinkedList<Course>();
        AddCourses(AllPreliminaryCourses,this);
        Sorter.bSort(AllPreliminaryCourses);
        return AllPreliminaryCourses;
    }

    private void  AddCourses(List<Course>AllPreliminaryCourses,Course Course) {  //Auxiliary function to add Preliminary Courses to List of all Preliminary Courses.

        for (int i = 0; i < Course.getPreliminaryCourses().size(); i = i + 1) { //For each pre-course, examine their pre-courses and add all pre-courses of all through recursive action by which we add to the list all sub-lists of the pre-courses.
            if ((Course.getPreliminaryCourses() != null)&&(!AllPreliminaryCourses.contains(Course.getPreliminaryCourses().get(i)))) {  //If the current course has pre-courses and even if it does not already appear in the general list of all previous courses.
                AllPreliminaryCourses.add(Course.getPreliminaryCourses().get(i));
                AddCourses(AllPreliminaryCourses, Course.getPreliminaryCourses().get(i)); //Recursive action which sends the list of pre-courses and pre-current course that I want to add to the list of pre-courses.
            } else if (Course.getPreliminaryCourses() == null && (!AllPreliminaryCourses.contains(Course.getPreliminaryCourses().get(i))) ) { //The conditions of the recursion.
                AllPreliminaryCourses.add(Course.getPreliminaryCourses().get(i));
            }
        }
    }
    public void addPreliminaryCourse(Course course){
        if (course==null) throw new NullPointerException(); // If the course is null we cant to add him to the list.
        if (!this.preCourses.contains(course))   // Just if the preCourses list does not contains the course we add him to the list.
        this.preCourses.add(course);
    }

    public void addPreliminaryCourses(List<Course> courses){
        if (courses==null) throw new NullPointerException(); // If the list are null we cant to add her to the list.
        if (!this.preCourses.containsAll(courses))
            this.preCourses.addAll(courses);   // Just if the preCourses list does not contains the List courses we add her to the list.
    }

    public boolean isPreliminaryCourse(Course other){
        return other.getAllPreliminaryCourses().contains(this);
    }

    public int compareTo(Course other) {

        if(isPreliminaryCourse(other)==false){
            if (other.getNumber()>this.getNumber()) return 1;
            return -1;
        }
        return 1;
    }

    private boolean onlyLettersAndSpaces(String str) {
        boolean isLetter = true;
        for (int i = 0; i < str.length() & isLetter ; i++) {
            char c = str.charAt(i);
            isLetter = c == ' ' | (c >= 'a' & c <= 'z') | (c >= 'A' & c <= 'Z') | '0' <= c & c <= '9';
        }
        return isLetter;
    }
}
