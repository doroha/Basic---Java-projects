package tasks;

import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Task4 {


    public static void main (String [] args) {


        Scanner Manner = new Scanner(System.in);



        int a = Manner.nextInt ();
        int b = Manner.nextInt ();
        int c = Manner.nextInt ();
        int r,mo,me,sum1,sum2,n,m;


        if (c==-1 )                               // במקרה וברצוננו לבדוק מכנה משותף עבור שני מספרים בלבד

        {

         mo=a;
         me=b;
         r=a%b;

            while (r != 0) {

                mo =me;
                me=r;
                r=a%b;

            }

            System.out.println(a/me+"");
            System.out.println(b/me+"");

        }

        else


            {

                mo=a;                                     //mo, me - variables to save the values of the meter and denominator of the fragment we get

                me=b;

            while (c != -1)                   // As long as we don't put value -1 the loop will continue to calculate the sum of the resulting fractions until it displays as a small fraction output

            {

                int d = Manner.nextInt();
                sum1 = d*mo + c*me;
                sum2 =d*me;
                r = sum1 % sum2;
                n = sum1;
                m = sum2;

                while (r != 0) {
                    n = m;
                    m = r;
                    r = n % m;
                }

                mo=sum1/m;
                me=sum2/m;

                c = Manner.nextInt();


            }

                System.out.println(mo+"");
                System.out.println(me+"");


        }


    }

}
