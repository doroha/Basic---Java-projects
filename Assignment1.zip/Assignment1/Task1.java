package tasks;

import java.util.Scanner;

public class Task1 {
    public static void main (String [] args) {

        Scanner Manner = new Scanner(System.in);

        int m = Manner.nextInt ();
        int n = Manner.nextInt ();
        int l = Manner.nextInt ();

        int temp;                       // temp - Variable to store the maximum value  in performing Conditional transient operation

        if ( m > n ) {
            temp = m;
            m = n;
            n = temp;
        }

        if(m > l) {
            temp = m;
            m = l;
            l = temp;
        }

        if(n > l) {
            temp = n;
            n = l;
            l = temp;
        }

        System.out.println(m);
        System.out.println(n);
        System.out.println(l);



        }

    }



