package tasks;

import java.util.Scanner;

public class Task3 {


    public static void main (String [] args) {

        Scanner Manner = new Scanner(System.in);

        int a = Manner.nextInt ();
        int b = Manner.nextInt ();
        int c = Manner.nextInt ();
        int d = Manner.nextInt ();

        int sum1 = (a*d) + (c*b) ;            //sum1 - The value of the  meter obtained from the sum of the non-fractional fractions
        int sum2 = b*d ;                      //sum2-  The value of the denominator obtained from the sum of the non-fractional fractions
        int r = sum1 % sum2 ;                // r- The remainder of the division between the meter to the denominator of the fraction non limited received
        int n=sum1;
        int m=sum2;

        while (r != 0) {                      // Loop to calculate maximal common divisor with the meter and denominator
            n = m;
            m = r;
            r = n % m;
        }

        System.out.println(sum1/m+"");
        System.out.println(sum2/m+"");


    }

}
