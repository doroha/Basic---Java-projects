package tasks;


import java.util.Scanner;

public class Task5 {


    public static void main (String [] args) {


        Scanner Manner = new Scanner(System.in);

        int a = Manner.nextInt ();
        int b = Manner.nextInt ();
        int c = Manner.nextInt ();
        int max;                                    //max- variable to store the maximum value of the three numbers

                                                    // The program checks which the largest number of the three entries that are received
                                                    // with a conditional pass we check wich one is the largest
													//    the smalle one will be in the value - (a)   
        if ( a > b ) {
            max = a;
            a = b;
            b = max;
        }

        if(a > c) {
            max = a;
            a = c;
            c = max;
        }

        if(b > c) {
            max = b;
            b = c;
            c = max;
        }

        System.out.println(a);
        System.out.println(b);















    }

}
