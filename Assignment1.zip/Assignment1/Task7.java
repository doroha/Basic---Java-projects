package tasks;

import java.util.Scanner;

public class Task7 {

    public static void main (String [] args) {

        Scanner Manner = new Scanner(System.in);


        int a=0;
        int b=0;
        int c=0;
        int d=0;
        int max;
        boolean verified=true;                                            // verified - Boolean variable to Verify the correctness of the previous program


            for (int n1 = 0; n1 < 2; n1++) {                             //  examination all options for testing the program that we code in the previous task
                for (int n2 = 0; n2 < 2; n2++) {                         // with 4 loops we chek all 2^4 = 16 options 
                    for (int n3 = 0; n3 < 2; n3++) {                     // Two possible values ​​for each variable (0 or 1)
                        for (int n4 = 0; n4 < 2; n4++) {

                          if (verified) {                                //  As long as the Boolean variable we defined as a value of truth we will continue to examine what the minimal values ​​are
                                                                        
                              a = n1;
                              b = n2;
                              c = n3;
                              d = n4;


                              if (a > b) {                                       // Code lines of task 6
                                  max = a;
                                  a = b;
                                  b = max;
                              }


                              if (a > c) {
                                  max = a;
                                  a = c;
                                  c = max;
                              }


                              if (b > c) {
                                  max = b;
                                  b = c;
                                  c = max;
                              }



                              if (b > d) {
                                  max = b;
                                  b = d;
                                  d = max;
                              }


                             if ((a > c) || (a > d) || (b > c) || (b > d)){           // In a situation that (a) or (b) is bigger then (c) or (d) our program is not good and our boolean variable will be false
                                                                                      
                                 verified=false;                                      


                              }


                          }

                        }
                    }
                }
            }


            if (verified){                                //  if our task 6 program is works properly we print "verified" 

                System.out.println("verified");

            }

            else {

                System.out.println(a);
                System.out.println(b);
                System.out.println(c);
                System.out.println(d);
            }


    }
}
