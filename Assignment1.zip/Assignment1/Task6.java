package tasks;

import java.util.Scanner;

public class Task6 {

    public static void main (String [] args) {


        Scanner Manner = new Scanner(System.in);
		

        int a = Manner.nextInt();
        int b = Manner.nextInt();
        int c = Manner.nextInt();
        int d = Manner.nextInt();
        int max;
											 

        if ( a > b ) {
            max = a;
            a = b;
            b = max;
        }

        if(a > c) {
            max = a;
            a = c;
            c = max;
        }

        if(b > c) {
            max = b;
            b = c;
            c = max;
        }

        if (b>d)                                   // This program is similar to the previous program we did in the previous task is upgraded and calculates the values
        {                                          // this "if" check if the the second smallest value is small then the forth number we get
            max=b;
            b=d;
            d=max;
        }


        System.out.println(a);
        System.out.println(b);



    }

}
