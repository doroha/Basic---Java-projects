package tasks;

import java.util.Scanner;

public class Task2 {

    public static void main (String [] args) {

        Scanner Manner = new Scanner(System.in);

            int m = Manner.nextInt ();

            for (int i=2 ; i<=m ; i++ )                    // The loop runs on all values ​​from 2 to the number we got
            {

                while (m%i==0)                             // In this loop we test for which values ​​the resulting number is divisible by
				                                         
                {
                    System.out.println(i+"");
                    m= m/i;

                }


            }


        }
    }




